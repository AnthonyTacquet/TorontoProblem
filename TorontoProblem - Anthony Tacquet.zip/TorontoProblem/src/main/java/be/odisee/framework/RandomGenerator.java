package be.odisee.framework;
import java.util.Random;

public class RandomGenerator {
    public static final Random random  = new Random(1);
}
